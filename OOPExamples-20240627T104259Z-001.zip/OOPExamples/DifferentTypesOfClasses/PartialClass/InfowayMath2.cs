﻿namespace DifferentTypesOfClasses
{
    partial class BasicMath
    {
        public int Subtract(int i, int j)
        {
            return i - j;
        }
    }
}