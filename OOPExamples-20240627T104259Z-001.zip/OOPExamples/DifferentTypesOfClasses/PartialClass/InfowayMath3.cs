﻿namespace DifferentTypesOfClasses
{
    partial class BasicMath
    {
        public int Multiply(int i, int j)
        {
            return i * j;
        }
    }
}