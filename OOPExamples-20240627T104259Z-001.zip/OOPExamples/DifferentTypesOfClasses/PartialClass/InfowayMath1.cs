﻿namespace DifferentTypesOfClasses
{
	partial class BasicMath
	{
		public int Addition(int i,int j)
		{
			return i + j;
		}
	}
}