﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DifferentTypesOfClasses.Models
{
    internal static class Counter
    {
        public static int Count { get; set; } = 1;
    }
}
