﻿namespace InterfaceExamples.Contracts
{
    internal interface IBiology
    {
        string BiologyCalci();
    }
}
