﻿namespace InterfaceExamples.Contracts
{
    internal interface IDepartmentHod:IPhysics,IChemistry,IBiology
    {
    }
}
