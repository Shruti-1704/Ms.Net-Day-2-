﻿namespace InterfaceExamples.Contracts
{
    internal interface IPhysics
    {
        double PhysicsCalci();
    }
}
