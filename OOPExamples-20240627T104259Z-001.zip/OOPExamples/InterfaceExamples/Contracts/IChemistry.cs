﻿namespace InterfaceExamples.Contracts
{
    internal interface IChemistry
    {
        string ChemistryCalci();
    }
}
