﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Parent p1 = new Parent();
            //Parent p2 = new Parent(100, "Pravin");
            //Parent p3 = new Parent(p2);
            Child c1=new Child(101,"Manisha K.");
        }
    }
}
